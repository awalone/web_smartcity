<?php
/**
 * Created by PhpStorm.
 * User: Fadhli
 * Date: 11/21/2015
 * Time: 4:07 PM
 */

include "../connection.php";

$db = Database::getInstance();
$mysqli = $db->getConnection();
error_reporting(0);

/*
 * get data from $http.post request
 *
 *
 */
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$ktp = $request->ktp;
$nama = $request->nama;

$sql_query = "UPDATE user SET nama = '$nama' WHERE ktp = '$ktp'";
$result = $mysqli->query($sql_query);


