<?php

 /*define('HOST','192.168.23.23');
 define('USER','daeng_sampah');
 define('PASS','daeng_sampah');
 define('DB','daengsampah');*/
 
 define('HOST','localhost');
 define('USER','awalone');
 define('PASS','sur!4lambintiumar');
 define('DB','awalone_thesis');

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect to db');
?>
