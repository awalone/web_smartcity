/**
 * Created by Fadhli on 11/18/2015.
 */
myApp.controller('berandaCtrl',function ($scope,$http) {

});