/**
 * Created by Fadhli on 11/25/2015.
 */
myApp.controller('siteCtrl',function($scope){
});